<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AdminVoiceFeedback {

    public function __construct() {
        add_action('admin_menu', [__CLASS__, 'register_admin_menu']);
    }
    
 
    public static function register_admin_menu() {
        
        // Top-level menu: Voice Feedback
        add_menu_page(
            'Voice Feedback',              
            'Voice Feedback',             
            'manage_options',                
            'voice-feedback',               
            [__CLASS__, 'render_users_feedbacks_page'], 
            'dashicons-microphone',          
            25    
        );

        // Submenu: User Feedback
        add_submenu_page(
            'voice-feedback',
            'All Feedback', 
            'All Feedback', 
            'manage_options', 
            'voice-feedback', 
            [__CLASS__, 'render_users_feedbacks_page']
        );
        
        // Submenu: Add New Feedback
        add_submenu_page(
            'voice-feedback',
            'Add New Feedback',
            'Add New Feedback',
            'manage_options',
            'all-voice-feedback',
            [__CLASS__, 'render_all_voice_feedback_page']
        );

        // Submenu: Global Feedback Templates
        add_submenu_page(
            'voice-feedback',
            'Voice Setting',
            'Global Feedback Templates',
            'manage_options',
            'global-feedback-settings',
            [__CLASS__, 'render_global_settings_page']
        );

        // Submenu: Feedback Settings
        add_submenu_page(
            'voice-feedback',
            'Settings',
            'Settings',
            'manage_options',
            'bplvf-global-settings',
            [__CLASS__, 'render_feedback_settings_page']
        );

        // Submenu: Demo & Help
         add_submenu_page(
            'voice-feedback',
            'Help & Demos',
            __('<span style="color: #f18500;">Help & Demos</span>', "voice-feedback"),   
            'manage_options',
            'bplvf-dashboard',
            [__CLASS__,'render_dashboard_page']
        );
    }

    public static function render_dashboard_page() {
        ?>
        <div id="bplvfAdminDashboardPageWrapper"
        data-info='<?php echo esc_attr( wp_json_encode( [
					'version'    => BPLVF_VERSION,
					'isPremium'  => bplvf()->can_use_premium_code(),
					'hasPro'     => BPLVF_HAS_PRO,
					'licenseActiveNonce' => wp_create_nonce( 'bPlLicenseActivation' )
				] ) ); ?>'
        ></div>
        <?php
    }

    // Users Feedback Page
    public static function render_users_feedbacks_page() {
    ?>
        <style>
            #wpcontent {
                padding: 0 !important;
            }
        </style>
        <div
           class="vfd-settings-page-wrapper" id="vfdUsersFeedbacksWrapper"
           data-is-premium="<?php echo esc_attr(bplvf()->can_use_premium_code() ?? false); ?>"
           data-user="https://www.gravatar.com/avatar/<?php echo esc_attr(md5(strtolower(trim(get_userdata(get_current_user_id())->user_email)))); ?>?s=32"
        >
        </div>
    <?php
    }

    // Start Global Voice Feedback Page
    public static function render_global_settings_page() {
        ?>
          <style>
            #wpcontent {
                padding: 0 !important;
            }
          </style>
          <div class="vfd-settings-page-wrapper" 
             id="vfdSettingsWrapper"
             data-info='<?php echo esc_attr( wp_json_encode( [
                  'isPremium' => esc_attr(bplvf()->can_use_premium_code() ?? false),
                  'adminUrl' => admin_url(),
              ] ) ); ?>'>
          </div>
        <?php
      }
    
    // All Voice Feedback
    public static function render_all_voice_feedback_page() {
        ?>
        <style>
            #wpcontent {
                padding: 0 !important;
            }
        </style>
        <div
           id="allFeedbackPageWrapper" 
           data-info='<?php echo esc_attr( wp_json_encode( [
                'isPremium' => esc_attr(bplvf()->can_use_premium_code() ?? false),
                'adminUrl' => admin_url(),
            ] ) ); ?>'>
        </div>
        <?php
    }

    // Feedback Settings
    public static function render_feedback_settings_page() {
        ?>
          <style>
            #wpcontent {
                padding: 0 !important;
            }
          </style>
          <div class="vfd-settings-page-wrapper" 
             id="bplvfFeedbackSettingsWrapper"
             data-user="https://www.gravatar.com/avatar/<?php echo esc_attr(md5(strtolower(trim(get_userdata(get_current_user_id())->user_email)))); ?>?s=32"
             data-info='<?php echo esc_attr( wp_json_encode( [
                'isPremium' => esc_attr(bplvf()->can_use_premium_code() ?? false),
                'adminUrl' => admin_url(),
            ] ) ); ?>'>
          </div>
        <?php
      }

}
new AdminVoiceFeedback();
